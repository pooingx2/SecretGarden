#!bin/sh

cd authServ && ./authServ 12600 &
cd ..
