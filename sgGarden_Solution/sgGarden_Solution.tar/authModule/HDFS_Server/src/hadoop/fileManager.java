package hadoop;

public class fileManager {

	String path = " default path ";
	String data = " default data ";
	int index = 77;
	
	
	public String save_mdata_to_HDFS(String token, String token2) {
	    // TODO Auto-generated method stub
		
		return path;
	}

	
	public String get_mdata_from_Mpath(String token) {
		// TODO Auto-generated method stub
		return data;
		
	}

	public String get_path_from_Index(int index2) {
		// TODO Auto-generated method stub
		return path;
	}


	




	
}
