#!bin/sh

cd dirServ && ./dirServ 12600 &
cd ..
