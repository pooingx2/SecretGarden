#!/bin/sh

cd HDFS_Server && ./HDFS_ServJar.jar &
cd ..
