
echo "Compile 소스 파일"
make

echo "VPN 실행"
sudo openvpn --config /etc/openvpn/openvpn.conf 



