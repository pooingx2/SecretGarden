#!bin/sh

cd dirServ && ./dirServ 127.0.0.1 12600 &
cd ..
