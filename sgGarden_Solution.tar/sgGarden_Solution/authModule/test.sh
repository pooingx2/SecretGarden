#!/bin/bash

testvar=""

echo -n "test"
read -s testvar
