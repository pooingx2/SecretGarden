#!bin/sh

cd authServ && ./authServ 127.0.0.1  12600 &
cd ..
